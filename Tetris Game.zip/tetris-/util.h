#ifndef _UTIL_H_
#define _UTIL_H_

enum Color { RED, GREEN, BLUE, YELLOW, MAGENTA, CYAN, BLACK };
void BitmapText(char *str, int wcx, int wcy, void *font, Color color);

#endif

